import pandas as pd
import numpy as np
import sys
import sklearn
import io
import random
import joblib
from sklearn.svm import SVC
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from sklearn import preprocessing

# Define column names
col_names = ["duration", "protocol_type", "service", "flag", "src_bytes", "dst_bytes",
             "land", "wrong_fragment", "urgent", "hot", "num_failed_logins",
             "logged_in", "num_compromised", "root_shell", "su_attempted", "num_root",
             "num_file_creations", "num_shells", "num_access_files", "num_outbound_cmds",
             "is_host_login", "is_guest_login", "count", "srv_count", "serror_rate",
             "srv_serror_rate", "rerror_rate", "srv_rerror_rate", "same_srv_rate",
             "diff_srv_rate", "srv_diff_host_rate", "dst_host_count", "dst_host_srv_count",
             "dst_host_same_srv_rate", "dst_host_diff_srv_rate", "dst_host_same_src_port_rate",
             "dst_host_srv_diff_host_rate", "dst_host_serror_rate", "dst_host_srv_serror_rate",
             "dst_host_rerror_rate", "dst_host_srv_rerror_rate", "label"]

# Read the training data
train = pd.read_csv('https://raw.githubusercontent.com/Hamzadil/ML_NIDS_SVM/main/Project%20Code/NSL_KDD_Train.csv',
                    header=None, names=col_names)

# Select categorical columns
categorical_columns = ['protocol_type', 'service', 'flag']
train_categorical_values = train[categorical_columns]

# Encode categorical values
unique_protocol = sorted(train.protocol_type.unique())
string1 = 'Protocol_type_'
unique_protocol2 = [string1 + x for x in unique_protocol]

unique_service = sorted(train.service.unique())
string2 = 'service_'
unique_service2 = [string2 + x for x in unique_service]

unique_flag = sorted(train.flag.unique())
string3 = 'flag_'
unique_flag2 = [string3 + x for x in unique_flag]

# Create encoded columns
dumcols = unique_protocol2 + unique_service2 + unique_flag2
train_categorical_values_enc = train_categorical_values.apply(LabelEncoder().fit_transform) # type: ignore

# One-hot encode categorical values
enc = OneHotEncoder(categories='auto')
train_categorical_values_encenc = enc.fit_transform(train_categorical_values_enc)
train_cat_data = pd.DataFrame(train_categorical_values_encenc.toarray(), columns=dumcols) # type: ignore

# Merge encoded categorical columns with the original training data
newtrain = train.join(train_cat_data)
newtrain.drop('flag', axis=1, inplace=True)
newtrain.drop('protocol_type', axis=1, inplace=True)
newtrain.drop('service', axis=1, inplace=True)

# Replace label values with numerical values
labeltrain = newtrain['label']
newlabeltrain = labeltrain.replace({
    'normal': 0, 'neptune': 1, 'back': 1, 'land': 1, 'pod': 1, 'smurf': 1, 'teardrop': 1, 'mailbomb': 1,
    'apache2': 1, 'processtable': 1, 'udpstorm': 1, 'worm': 1, 'ipsweep': 2, 'nmap': 2, 'portsweep': 2,
    'satan': 2, 'mscan': 2, 'saint': 2, 'ftp_write': 3, 'guess_passwd': 3, 'imap': 3, 'multihop': 3,
    'phf': 3, 'spy': 3, 'warezclient': 3, 'warezmaster': 3, 'sendmail': 3, 'named': 3, 'snmpgetattack': 3,
    'snmpguess': 3, 'xlock': 3, 'xsnoop': 3, 'httptunnel': 3, 'buffer_overflow': 4, 'loadmodule': 4,
    'perl': 4, 'rootkit': 4, 'ps': 4, 'sqlattack': 4, 'xterm': 4})
newtrain['label'] = newlabeltrain

# Separate the data for different attack types
to_drop_DoS = [0, 1]
to_drop_Probe = [0, 2]
to_drop_R2L = [0, 3]
to_drop_U2R = [0, 4]

DoS_train = newtrain[newtrain['label'].isin(to_drop_DoS)]
Probe_train = newtrain[newtrain['label'].isin(to_drop_Probe)]
R2L_train = newtrain[newtrain['label'].isin(to_drop_R2L)]
U2R_train = newtrain[newtrain['label'].isin(to_drop_U2R)]

# Separate features and labels for each attack type
X_DoS = DoS_train.drop('label', axis=1)
Y_DoS = DoS_train.label

X_Probe = Probe_train.drop('label', axis=1)
Y_Probe = Probe_train.label

X_R2L = R2L_train.drop('label', axis=1)
Y_R2L = R2L_train.label

X_U2R = U2R_train.drop('label', axis=1)
Y_U2R = U2R_train.label

# Perform feature scaling
colNames = list(X_DoS)

scaler1 = preprocessing.StandardScaler().fit(X_DoS)
X_DoS = scaler1.transform(X_DoS)

scaler2 = preprocessing.StandardScaler().fit(X_Probe)
X_Probe = scaler2.transform(X_Probe)

scaler3 = preprocessing.StandardScaler().fit(X_R2L)
X_R2L = scaler3.transform(X_R2L)

scaler4 = preprocessing.StandardScaler().fit(X_U2R)
X_U2R = scaler4.transform(X_U2R)

# Train SVM models for each attack type
svm_dos = SVC(kernel='linear', C=1.0, random_state=0)
svm_probe = SVC(kernel='linear', C=1.0, random_state=0)
svm_r2l = SVC(kernel='linear', C=1.0, random_state=0)
svm_u2r = SVC(kernel='linear', C=1.0, random_state=0)

svm_dos.fit(X_DoS, Y_DoS.astype(int))
svm_probe.fit(X_Probe, Y_Probe.astype(int))
svm_r2l.fit(X_R2L, Y_R2L.astype(int))
svm_u2r.fit(X_U2R, Y_U2R.astype(int))

# Save the trained models
joblib.dump(svm_dos, 'svm_dos_model.joblib')
joblib.dump(svm_probe, 'svm_probe_model.joblib')
joblib.dump(svm_r2l, 'svm_r2l_model.joblib')
joblib.dump(svm_u2r, 'svm_u2r_model.joblib')

# Load the saved models
svm_dos = joblib.load('svm_dos_model.joblib')
svm_probe = joblib.load('svm_probe_model.joblib')
svm_r2l = joblib.load('svm_r2l_model.joblib')
svm_u2r = joblib.load('svm_u2r_model.joblib')
print("Model Loaded.")
