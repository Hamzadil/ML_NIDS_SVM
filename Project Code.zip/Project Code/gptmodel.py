import pandas as pd
import numpy as np
import sys
import sklearn
import io
import random
import joblib
from sklearn.svm import SVC
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from sklearn import preprocessing
from scapy.all import *
from scapy.layers.inet import IP, TCP

# Define column names
col_names = ["duration", "protocol_type", "service", "flag", "src_bytes", "dst_bytes",
             "land", "wrong_fragment", "urgent", "hot", "num_failed_logins",
             "logged_in", "num_compromised", "root_shell", "su_attempted", "num_root",
             "num_file_creations", "num_shells", "num_access_files", "num_outbound_cmds",
             "is_host_login", "is_guest_login", "count", "srv_count", "serror_rate",
             "srv_serror_rate", "rerror_rate", "srv_rerror_rate", "same_srv_rate",
             "diff_srv_rate", "srv_diff_host_rate", "dst_host_count", "dst_host_srv_count",
             "dst_host_same_srv_rate", "dst_host_diff_srv_rate", "dst_host_same_src_port_rate",
             "dst_host_srv_diff_host_rate", "dst_host_serror_rate", "dst_host_srv_serror_rate",
             "dst_host_rerror_rate", "dst_host_srv_rerror_rate", "label"]

# Create an empty DataFrame to store the packet information
packet_data = pd.DataFrame(columns=col_names)

# Function to handle each packet
def process_packet(packet):
    global packet_data

    # Extract the relevant information from the packet
    packet_info = {
        'duration': packet.time,
        'protocol_type': packet[IP].proto,
        'service': packet[IP].sport,
        'flag': packet[TCP].flags,
        'src_bytes': packet[IP].len,
        'dst_bytes': 0,  # Assuming destination bytes are not available in the packet
        'land': 0,
        'wrong_fragment': 0,
        'urgent': 0,
        'hot': 0,
        'num_failed_logins': 0,
        'logged_in': 0,
        'num_compromised': 0,
        'root_shell': 0,
        'su_attempted': 0,
        'num_root': 0,
        'num_file_creations': 0,
        'num_shells': 0,
        'num_access_files': 0,
        'num_outbound_cmds': 0,
        'is_host_login': 0,
        'is_guest_login': 0,
        'count': 0,
        'srv_count': 0,
        'serror_rate': 0,
        'srv_serror_rate': 0,
        'rerror_rate': 0,
        'srv_rerror_rate': 0,
        'same_srv_rate': 0,
        'diff_srv_rate': 0,
        'srv_diff_host_rate': 0,
        'dst_host_count': 0,
        'dst_host_srv_count': 0,
        'dst_host_same_srv_rate': 0,
        'dst_host_diff_srv_rate': 0,
        'dst_host_same_src_port_rate': 0,
        'dst_host_srv_diff_host_rate': 0,
        'dst_host_serror_rate': 0,
        'dst_host_srv_serror_rate': 0,
        'dst_host_rerror_rate': 0,
        'dst_host_srv_rerror_rate': 0,
        'label': 'unknown'  # Set the label as 'unknown' for now
    }

    # Add the packet information to the DataFrame
    packet_data = packet_data.append(packet_info, ignore_index=True) # type: ignore

# Choose the network interface to capture packets from
interface = 'eth0'  # Replace with the appropriate NIC name

# Sniff packets on the chosen interface and process them
sniff(prn=process_packet, iface=interface, count=100)

# Load the trained models
svm_dos = joblib.load('svm_dos_model.joblib')
svm_probe = joblib.load('svm_probe_model.joblib')
svm_r2l = joblib.load('svm_r2l_model.joblib')
svm_u2r = joblib.load('svm_u2r_model.joblib')

# Select categorical columns
categorical_columns = ['protocol_type', 'service', 'flag']
packet_categorical_values = packet_data[categorical_columns]

# Encode categorical values
unique_protocol = sorted(packet_data.protocol_type.unique())
string1 = 'Protocol_type_'
unique_protocol2 = [string1 + x for x in unique_protocol]

unique_service = sorted(packet_data.service.unique())
string2 = 'service_'
unique_service2 = [string2 + x for x in unique_service]

unique_flag = sorted(packet_data.flag.unique())
string3 = 'flag_'
unique_flag2 = [string3 + x for x in unique_flag]

# Create encoded columns
dumcols = unique_protocol2 + unique_service2 + unique_flag2
packet_categorical_values_enc = packet_categorical_values.apply(LabelEncoder().fit_transform) # type: ignore

# One-hot encode categorical values
enc = OneHotEncoder(categories='auto')
packet_categorical_values_encenc = enc.fit_transform(packet_categorical_values_enc)
packet_cat_data = pd.DataFrame(packet_categorical_values_encenc.toarray(), columns=dumcols) # type: ignore

# Merge encoded categorical columns with the original packet data
newpacket = packet_data.join(packet_cat_data)
newpacket.drop('flag', axis=1, inplace=True)
newpacket.drop('protocol_type', axis=1, inplace=True)
newpacket.drop('service', axis=1, inplace=True)

# Scale the features
colNames = list(newpacket)
scaler = preprocessing.StandardScaler().fit(newpacket)
newpacket = scaler.transform(newpacket)

# Make predictions for each packet using the SVM models
dos_predictions = svm_dos.predict(newpacket)
probe_predictions = svm_probe.predict(newpacket)
r2l_predictions = svm_r2l.predict(newpacket)
u2r_predictions = svm_u2r.predict(newpacket)

# Update the 'label' column in packet_data with the predicted labels
packet_data['label'] = np.where(dos_predictions == 1, 'DoS', packet_data['label'])
packet_data['label'] = np.where(probe_predictions == 1, 'Probe', packet_data['label'])
packet_data['label'] = np.where(r2l_predictions == 1, 'R2L', packet_data['label'])
packet_data['label'] = np.where(u2r_predictions == 1, 'U2R', packet_data['label'])

# Print the extracted packet data with predicted labels
print(packet_data)